export const squared = (n: number) => n * n
